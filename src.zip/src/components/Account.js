import fishpic from '../assets/placeholder.png';
{/*Sekcja z kategoriami*/}
function Account() {
  const auth = getAuth();
  const user = auth.currentUser;

  if (!user) {
    return <Redirect to="/register" />;
  }
  return (
    <>
    </>
  )
}

const categories = [
  { name: "Odzież"},
  { name: "Kołowrotki"},
  { name: "Przynęty"},
  { name: "Wędki"},
  { name: "Żyłki"},
  { name: "Haczyki"},
]

export default Account

