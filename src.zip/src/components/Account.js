import React, { useEffect, useState } from 'react';
import user from '../assets/user.png';
import Navbar from "./Navbar";
import Footer from "./Footer";
import "../styles.css";
import { app } from '../firebase'; // Importuj swoją konfigurację Firebase

function Account() {
  const [userData, setUser] = useState(null); // Poprawiona nazwa funkcji
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const user = app.currentUser ; // Pobierz aktualnego użytkownika

    if (user) {
      // Użytkownik jest zalogowany
      setUser({
        email: user.email,
        uid: user.uid,
        // Możesz dodać inne dane, jeśli są dostępne
      });
    } else {
      // Użytkownik nie jest zalogowany
      setUser(null);
    }
    setLoading(false);
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <Navbar />
      <div className="registration">
        <div className="registration-form">
          {userData ? (
            <>
              <h1>Szczegóły konta</h1>
              <img src={user} alt="user icon" />
              <p>E-mail: {userData.email}</p>
              <p>ID użytkownika: {userData.uid}</p>
              <hr />
              <h1>Modyfikacja konta</h1>
            </>
          ) : (
            <p>Nie jesteś zalogowany.</p>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
}

export default Account;